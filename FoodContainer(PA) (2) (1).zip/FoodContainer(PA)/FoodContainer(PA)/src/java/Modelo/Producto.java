/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Rafael
 */

import java.io.InputStream;

public class Producto {
    
     private int codigoProducto;
    private String nombre;
    private int calorias,cantidad;
     private String archivoimg;
     private int Tproducto;

    public Producto() {
        
    }

    public Producto(int codigoProducto, String nombre, int calorias, int cantidad, String archivoimg,int Tproducto) {
        this.codigoProducto = codigoProducto;
        this.nombre = nombre;
        this.calorias = calorias;
        this.cantidad = cantidad;
        this.archivoimg = archivoimg;
        this.Tproducto = Tproducto;
    }

  
    public int getTproducto() {
        return Tproducto;
    }

    public void setTproducto(int Tproducto) {
        this.Tproducto = Tproducto;
    }
    
    

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getArchivoimg() {
        return archivoimg;
    }

    public void setArchivoimg(String archivoimg) {
        this.archivoimg = archivoimg;
    }
     
     
    
    
    
}
