/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author Rafael
 */

import java.sql.*;

public class Conexion {
    
    public static Connection getConnection(){
        
        String url, userName, password;
        
        url = "jdbc:mysql://us-cdbr-east-04.cleardb.com/heroku_ea39a82b9544198";
        userName = "b94571515bfe19";
        password = "d7111b15";
        
        Connection con = null;
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, userName, password);
            System.out.println("Se conecto a la BD");
        
        }catch(Exception e){
            System.out.println("No se conecto a la BD");
            System.out.println(e.getMessage());
        
        }
        return con;
    }
    
}
