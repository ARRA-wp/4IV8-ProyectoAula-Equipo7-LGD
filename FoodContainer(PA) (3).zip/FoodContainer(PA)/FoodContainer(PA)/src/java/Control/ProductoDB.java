/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;



import Modelo.Producto;
import Modelo.ProductoB;
import java.sql.*;
import java.util.ArrayList;



public class ProductoDB {
    
    //Permite Listar los productos para su consulta de tipo bebidas
    
    public static ArrayList<ProductoB> obtenerProductoB(){
    
        ArrayList<ProductoB> lista = new ArrayList<ProductoB>();
        
        try{
            
            CallableStatement cl = Conexion.getConnection().prepareCall("{call listarProductosB()}");
            ResultSet rs = cl.executeQuery();
            while(rs.next()){
                ProductoB p = new ProductoB(rs.getInt(1),rs.getString(2),rs.getInt(3) ,rs.getInt(4),rs.getString(5));
            lista.add(p);
            }
        
        }catch(Exception e){
            System.out.println("Nope");
             System.out.println(e.getMessage());
        
        }
        return lista;
        
        
    }
    //Productos de canasta basica
    public static ArrayList<ProductoB> obtenerProductoCB(){
    
        ArrayList<ProductoB> lista = new ArrayList<ProductoB>();
        
        try{
            
            CallableStatement cl = Conexion.getConnection().prepareCall("{call listarProductosCB()}");
            ResultSet rs = cl.executeQuery();
            while(rs.next()){
                ProductoB p = new ProductoB(rs.getInt(1),rs.getString(2),rs.getInt(3) ,rs.getInt(4),rs.getString(5));
            lista.add(p);
            }
        
        }catch(Exception e){
            System.out.println("Nope");
             System.out.println(e.getMessage());
        
        }
        return lista;
        
        
    }
    //Obtener productos tipo Snack
    public static ArrayList<ProductoB> obtenerProductoS(){
    
        ArrayList<ProductoB> lista = new ArrayList<ProductoB>();
        
        try{
            
            CallableStatement cl = Conexion.getConnection().prepareCall("{call listarProductosS()}");
            ResultSet rs = cl.executeQuery();
            while(rs.next()){
                ProductoB p = new ProductoB(rs.getInt(1),rs.getString(2),rs.getInt(3) ,rs.getInt(4),rs.getString(5));
            lista.add(p);
            }
        
        }catch(Exception e){
            System.out.println("Nope");
             System.out.println(e.getMessage());
        
        }
        return lista;
        
        
    }
    
    //Obtener productos tipo Snack
    public static ArrayList<ProductoB> obtenerProductos(){
    
        ArrayList<ProductoB> lista = new ArrayList<ProductoB>();
        
        try{
            
            CallableStatement cl = Conexion.getConnection().prepareCall("{call listarProductos()}");
            ResultSet rs = cl.executeQuery();
            while(rs.next()){
                ProductoB p = new ProductoB(rs.getInt(1),rs.getString(2),rs.getInt(3) ,rs.getInt(4),rs.getString(5));
            lista.add(p);
            }
        
        }catch(Exception e){
            System.out.println("Nope");
             System.out.println(e.getMessage());
        
        }
        return lista;
        
        
    }
    
    //Obtener un solo producto
    public static ProductoB obtenerProducto(int codigo){
    ProductoB p=null;
    try{
        CallableStatement cl = Conexion.getConnection().prepareCall("{call sp_ProductoCod(?)}");
        cl.setInt(1,codigo);
        ResultSet rs = cl.executeQuery();
        while(rs.next()){
            p= new ProductoB(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getInt(4),rs.getString(5));
        
        }
        
        
    }catch(Exception e){
        
        System.out.println("Nope");
             System.out.println(e.getMessage());
    }
    
    return p;
    
    }
    
    
    
    
}