/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

import Modelo.DCarrito;
import Modelo.Producto;
import Modelo.ProductoB;
import Modelo.Usuario;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rafael
 */
public class AccionesProducto {
    
    //Agregar Un usuario
     public static int registrarProducto(Producto e){
        int estatus = 0;
        try{
            Connection con = Conexion.getConnection();
            String q = "insert into cproducto(nom_pro, cal_pro, cant_pro, img_pro, id_tpro) "
                    + "values(?,?,?,?,?)";
            
            PreparedStatement ps = con.prepareStatement(q);
            
            ps.setString(1, e.getNombre());
            ps.setInt(2, e.getCalorias());
            ps.setInt(3, e.getCantidad());
            ps.setString(4, e.getArchivoimg());
             ps.setInt(5, e.getTproducto());
            
            estatus = ps.executeUpdate();
            System.out.println("Registro de Producto exitoso");
            con.close();
        }catch(Exception ed){
            System.out.println("Error al registar al usuario");
            System.out.println(ed.getMessage());
        
        }
        return estatus;
        
    }
     
     //Actualizar Usuario
    
    public static int actualizarProducto(Producto e){
        int estatus = 0;
        try{
            Connection con = Conexion.getConnection();
            String q = "update cproducto set nom_pro = ?, cal_pro = ?,"
                    + "cant_pro = ?, img_pro = ? , id_tpro = ? "
                    + " where id_pro = ?";
            
            PreparedStatement ps = con.prepareStatement(q);
            
            ps.setString(1, e.getNombre());
            ps.setInt(2, e.getCalorias());
            ps.setInt(3, e.getCantidad());
            ps.setString(4, e.getArchivoimg());
            ps.setInt(5, e.getTproducto());
             ps.setInt(6, e.getCodigoProducto());
            
            estatus = ps.executeUpdate();
            System.out.println("Actualizacion del Producto exitosa");
            con.close();
        }catch(Exception ed){
            System.out.println("Error al actualizar al usuario");
            System.out.println(ed.getMessage());
        
        }
        return estatus;
        
    }
    
    //Borrar usuario
    
     public static int borrarProducto(int id){
        int estatus = 0;
        try{
            Connection con = Conexion.getConnection();
            String q = "delete from cproducto where id_pro = ?";
            
            PreparedStatement ps = con.prepareStatement(q);
            
            ps.setInt(1, id);
            
            estatus = ps.executeUpdate();
            System.out.println("Eliminacion del Producto exitoso");
            con.close();
        }catch(Exception ed){
            System.out.println("Error al borrar al usuario");
            System.out.println(ed.getMessage());
        
        }
        return estatus;
        
    }
    
     
     
     //Consultar a todos los usuarios
     
     public static List<Usuario> getAllUsuario(){
        List<Usuario> lista = new ArrayList<Usuario>();
        
        try{
            Connection con = Conexion.getConnection();
            String q = "select * from musuario";
            
            PreparedStatement ps = con.prepareStatement(q);

            
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Usuario e = new Usuario();
                e.setId(rs.getInt(1));
                e.setNombre(rs.getString(2));
                e.setPassword(rs.getString(3));
                e.setEmail(rs.getString(4));
                e.setTusuario(rs.getInt(5));
                e.setEdad(rs.getInt(6));
                lista.add(e);
            }
            System.out.println("Se encontro a los usuario");
            con.close();
        }catch(Exception ed){
            System.out.println("Error al buscar a los Usuario");
            System.out.println(ed.getMessage());
        
        }
        return lista;
        
    }
     
     //Añadir Carrito
     public static ArrayList<DCarrito> AñadirCarrito(DCarrito d){
     
     ArrayList<DCarrito> lista = new ArrayList<DCarrito>();
         
      try{

                DCarrito u = new DCarrito();
                
            u.getCodigoProducto();
            u.getNombre();
            u.getCalorias();
            u.getNumpro();
            
            lista.add(u);
            
        
        }catch(Exception e){
            System.out.println("Nope");
             System.out.println(e.getMessage());
        
        }
        return lista;
         
         
     }
    
    
}
