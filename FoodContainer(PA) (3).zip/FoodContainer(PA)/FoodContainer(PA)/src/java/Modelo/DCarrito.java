/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author Rafael
 */
public class DCarrito {
    
     private int codigoProducto;
    private String nombre;
    private int calorias;
    private int numpro;

    
     public DCarrito() {
       
    }
     
    public DCarrito(int codigoProducto, String nombre, int calorias, int numpro) {
        this.codigoProducto = codigoProducto;
        this.nombre = nombre;
        this.calorias = calorias;
        this.numpro = numpro;
    }

    public int getCodigoProducto() {
        return codigoProducto;
    }

    public void setCodigoProducto(int codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCalorias() {
        return calorias;
    }

    public void setCalorias(int calorias) {
        this.calorias = calorias;
    }

    public int getNumpro() {
        return numpro;
    }

    public void setNumpro(int numpro) {
        this.numpro = numpro;
    }
    
    
    
    
    
    
    
    
    
}
